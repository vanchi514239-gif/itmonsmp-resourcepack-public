tellraw GenMode {color: "red", translate: "update.better_babies.mismatch"}
function better_babies:load/storage
$scoreboard players set *update better_babies $(update)