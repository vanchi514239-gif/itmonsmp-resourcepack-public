data modify storage better_babies:store entities[{id: "baby_bee"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_bee", states: {angry: false}}, model: "better_babies:entity/baby_bee"}, \
toggle: true, \
type: "minecraft:bee"}
data modify storage better_babies:store entities[{id: "baby_cat"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_cat", states: {has_owner: false}, track: ["color", "variant"]}, model: "better_babies:entity/baby_cat"}, \
toggle: true, \
type: "minecraft:cat"}
data modify storage better_babies:store entities[{id: "baby_ocelot"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_ocelot"}, model: "better_babies:entity/baby_ocelot"}, \
toggle: true, \
type: "minecraft:ocelot"}
data modify storage better_babies:store entities[{id: "baby_chicken"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_chicken"}, model: "better_babies:entity/baby_chicken"}, \
toggle: true, \
type: "minecraft:chicken"}
data modify storage better_babies:store entities[{id: "baby_cow"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_cow", track: ["variant"]}, model: "better_babies:entity/baby_cow"}, \
toggle: true, \
type: "minecraft:cow"}
data modify storage better_babies:store entities[{id: "baby_mooshroom"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_mooshroom", track: ["type"]}, model: "better_babies:entity/baby_mooshroom"}, \
toggle: true, \
type: "minecraft:mooshroom"}
data modify storage better_babies:store entities[{id: "baby_fox"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_fox", track: ["type"]}, model: "better_babies:entity/baby_fox"}, \
toggle: true, \
type: "minecraft:fox"}
data modify storage better_babies:store entities[{id: "baby_goat"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_goat"}, model: "better_babies:entity/baby_goat"}, \
toggle: true, \
type: "minecraft:goat"}
data modify storage better_babies:store entities[{id: "baby_llama"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_llama", track: ["variant"]}, model: "better_babies:entity/baby_llama"}, \
toggle: true, \
type: "minecraft:llama", \
variants: [{context: 'as @s[tag=ping.better_babies.swapped]', merge: {name: "entity.better_babies.baby_trader_llama"}, model: "better_babies:entity/baby_trader_llama"}]}
data modify storage better_babies:store entities[{id: "baby_pig"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_pig", track: ["variant"]}, model: "better_babies:entity/baby_pig"}, \
toggle: true, \
type: "minecraft:pig"}
data modify storage better_babies:store entities[{id: "baby_sheep"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_sheep", track: ["color"]}, model: "better_babies:entity/baby_sheep"}, \
toggle: true, \
type: "minecraft:sheep"}
data modify storage better_babies:store entities[{id: "baby_turtle"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_turtle"}, model: "better_babies:entity/baby_turtle"}, \
toggle: true, \
type: "minecraft:turtle"}
data modify storage better_babies:store entities[{id: "baby_wolf"}] merge value {\
default: {merge: {name: "entity.better_babies.baby_wolf", states: {angry: false, begging: false, has_owner: false}, track: ["color", "variant"]}, model: "better_babies:entity/baby_wolf"}, \
toggle: true, \
type: "minecraft:wolf"}