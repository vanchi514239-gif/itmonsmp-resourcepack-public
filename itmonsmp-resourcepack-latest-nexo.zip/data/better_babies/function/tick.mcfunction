execute if score *update data_api matches 10906 \
if score *update better_babies matches 804 \
run function better_babies:main