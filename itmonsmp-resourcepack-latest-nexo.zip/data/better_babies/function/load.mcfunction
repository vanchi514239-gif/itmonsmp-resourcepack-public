scoreboard objectives add data_api dummy
scoreboard objectives add better_babies dummy
execute if score *update data_api matches 10906 \
unless score *update better_babies matches 804 \
run function better_babies:load/main {update: 804}
execute unless score *update data_api matches 10906 \
run function better_babies:load/feedback {\
api_build: "1.9.6", \
dependency: "pack.data_api", \
name: "pack.better_babies"}