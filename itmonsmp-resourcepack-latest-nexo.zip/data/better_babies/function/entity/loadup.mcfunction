execute as @s[type=!minecraft:trader_llama, tag=!data.entity] \
if predicate data_api:flags/is_baby \
run function better_babies:entity/baby_mob/loadup
execute as @s[type=minecraft:trader_llama, tag=!data.entity] \
if predicate data_api:flags/is_baby \
if data storage better_babies:store entities[{id: "baby_llama", toggle: true}] \
run function better_babies:entity/swap_base
tag @s add init.better_babies