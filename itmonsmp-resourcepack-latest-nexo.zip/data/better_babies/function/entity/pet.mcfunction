tag @s[tag=!ping.better_babies.sitting] add private.better_babies.run0
tag @s[tag=ping.better_babies.sitting] add private.better_babies.run1
execute if entity @a[advancements={better_babies:player_interacted_with_entity/entities={pet_mob=true}}] \
run function data_api:command/run_command/from_array {commands: [\
'particle minecraft:heart ~ ~1 ~ 0 0 0 1 1 force', \
'scoreboard players set @a[advancements={better_babies:player_interacted_with_entity/entities={pet_mob=true}}] adv.trigger 7050000', \
'tag @s add private.better_babies.interact']}
data modify entity @s[tag=private.better_babies.run0,tag=private.better_babies.interact] Sitting set value false
data modify entity @s[tag=private.better_babies.run1,tag=private.better_babies.interact] Sitting set value true
tag @s[tag=private.better_babies.run0,tag=!private.better_babies.interact] add ping.better_babies.sitting
tag @s[tag=private.better_babies.run1,tag=!private.better_babies.interact] remove ping.better_babies.sitting
rotate @s[tag=private.better_babies.interact] facing entity @p[advancements={better_babies:player_interacted_with_entity/entities={pet_mob=true}}]
tag @s remove private.better_babies.interact
tag @s remove private.better_babies.run0
tag @s remove private.better_babies.run1