$data modify storage better_babies:private loadup.macro.model set value "$(model)"
$data modify storage better_babies:private loadup.macro merge value $(merge)