data modify storage better_babies:private loadup.macro set value {\
animate: 'true', \
item: "minecraft:poisonous_potato", \
model: false, \
name: false, \
states: {}, \
Tags: ["entity.better_babies.mob", "init.better_babies", "private.better_babies.init"], \
track: [], \
transformation: {}}
execute as @s[tag=ping.better_babies.swapped] run data modify storage better_babies:private loadup.macro.Tags append value "ping.better_babies.swapped"
execute as @s[nbt=!{Tame: true}] run data modify storage better_babies:private loadup.macro.Tags append value "track.better_babies.untame"
data modify entity @s[nbt=!{Tame: true}] Tame set value true
effect give @s minecraft:invisibility infinite 0 true
$execute if data storage better_babies:store entities[{type: "$(id)"}].default.context run function better_babies:entity/baby_mob/set_model_context with storage better_babies:store entities[{type: "$(id)"}].default
$execute unless data storage better_babies:store entities[{type: "$(id)"}].default.context run function better_babies:entity/baby_mob/set_model with storage better_babies:store entities[{type: "$(id)"}].default
$execute if data storage better_babies:store entities[{type: "$(id)"}].variants run data modify storage better_babies:private loadup.array set from storage better_babies:store entities[{type: "$(id)"}].variants
execute if data storage better_babies:private loadup.array[0] run function better_babies:entity/baby_mob/set_data_loop
$execute if data storage better_babies:store entities[{type: "$(id)", toggle: true}] run function better_babies:entity/summon with storage better_babies:private loadup.macro
execute on passengers run function data_api:entity/custom_mob/loadup