tag @s[type=minecraft:trader_llama] add ping.better_babies.swapped
execute as @s[type=minecraft:llama] run summon minecraft:trader_llama ~ ~ ~ {Tags: ["private.better_babies.target"]}
execute as @s[type=minecraft:trader_llama] run summon minecraft:llama ~ ~ ~ {Tags: ["private.better_babies.target"]}
tag @s[type=minecraft:llama] remove ping.better_babies.swapped
data modify entity @n[tag=private.better_babies.target] {} merge from entity @s {}
function data_api:entity/remove
tag @e remove private.better_babies.target